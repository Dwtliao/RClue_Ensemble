#### TOY DATA ####
set.seed(1234)
####LIBS AND SEED####
library(clue)
# install.packages("clusterCrit")
library(clusterCrit)
library(e1071)
library(cluster)

set.seed(1234)

#### LOAD DATA AND ASSIGN STUFF ####
data("Cassini")
toyData <- Cassini
data <- toyData$x  
nK <- 3

quality_measures <- c("Dunn", "Calinski_Harabasz", "Silhouette", "Davies_Bouldin",
                      "Xie_Beni", "SD_Dis")

# The SYNTHETIC cassini dataset consists of three groups, two banana-shaped clusters (non-convex) bending around a circular cluster in between them. 
str(Cassini)

plot(data, pch=19, main="Synthetic Cassini Data")
#col=Cassini$classes, 
####Pam plots ####
plot(data, col=pamSingle$clustering, pch=19, main="Single PAM Clustering")
plot(data, col=pamBag50.memberDf$hardClus, pch=19, main="Bagged PAM with 50 reps")
plot(data, col=pamBag100.memberDf$hardClus, pch=19, main="Bagged PAM with 100 reps")
plot(data, col=pamBag200.memberDf$hardClus, pch=19, main="Bagged PAM with 200 reps")


plot(data, col=pamSingle$clustering, pch=19, main="Single PAM Clustering", xlim=c(.4, 1.5),
     ylim=c(-1, 1))
plot(data, col=pamBag50.memberDf$hardClus, pch=19, main="Bagged PAM with 50 reps", 
     xlim=c(.4, 1.5), ylim=c(-1, 1))
plot(data, col=pamBag100.memberDf$hardClus, pch=19, main="Bagged PAM with 100 reps", 
     xlim=c(.4, 1.5),ylim=c(-1, 1))

#### single rep kmeans plots ####
plot(data, col=kmLloydSingle$cluster, pch=19, main="Single Lloyd Kmeans")

plot(data, col=kmHwSingle$cluster, pch=19, main="Single Hartigan-Wong Kmeans")
kmHwSingle$color <- ifelse(kmHwSingle$cluster == 2, yes=1, 
                           ifelse(kmHwSingle$cluster == 3, yes=2,
                                  ifelse(kmHwSingle$cluster == 1, yes = 3, no=NA)))
plot(data, col=kmHwSingle$color, pch=19, main="Single Hartigan-Wong Kmeans")

plot(data, col=kmMqSingle$cluster, pch=19, main="Single MacQueen Kmeans")

plot(data, col=kmSE.memberDf$color, pch=19, main="SE Consensus, all 3 kmeans methods")

plot(data, col=kmGV3.memberDf$color, pch=19, main="GV3 Consensus, all 3 kmeans methods")

angle <- pi
M <- matrix( c(cos(angle), -sin(angle), sin(angle), cos(angle)), 2, 2 )
plot( as.matrix(data) %*% M , col=kmGV3.memberDf$color, pch=19,
      main="GV3 Consensus, all 3 kmeans methods", xlab='data[,1]', ylab='data[,2]')

#### Hartigan Wong kmeans -- single / bagged / booted ####
plot(data, col=kmHwSingle$cluster, pch=19, main="Single Hartigan-Wong Kmeans")
clust.kmHwBag_50_2 <- bagItToyClusts(data, 50, "kmeans", 2, "Hartigan-Wong")
plot(data, col=color.kmHwBag_50_2, pch=19, main = "Bagged Hartigan-Wong Kmeans
     50 replicates")

clust.kmHwBag_100_2 <- bagItToyClusts(data, 100, "kmeans", 2, "Hartigan-Wong")
plot(data, col=clust.kmHwBag_100_2, pch=19, main= "Bagged Hartigan-Wong Kmeans
     100 replicates")



fuzzyToy <- cmeans(data, 3, iter.max=100, dist = "euclidean")
plot(data, col=fuzzyToy$color, pch=19, main="Single (Fuzzy) Cmeans")
clust.fuzzyBag_50_2 

#DBSCAN -- PERFECT MATCH FOR THIS
toyDbScan <- dbscan(toyData$x, 0.2)
plot(data, col=toyDbScan$cluster, pch=19, main="DB Scan")
toyDbScan.qual <- intCriteria(as.matrix(toyData$x), as.integer(toyDbScan$cluster), 
                              quality_measures)


#### MacQueen kmeans -- single / bagged / booted ####

plot(data, col=kmMqSingle$cluster, pch=19, main="Single MacQueen Kmeans")

clust.kmMqBag_50_2 <- bagItToyClusts(data, 50, "kmeans", 2, "MacQueen")
plot(data, col=clust.kmMqBag_50_2, pch=19)

clust.kmMqBag_100_2 <- bagItToyClusts(data, 100, "kmeans", 2, "MacQueen")
plot(data, col=clust.kmMqBag_100_2, pch=19)

clust.kmMqBag_50_3 <- bagItToyClusts(data, 50, "kmeans", 3, "MacQueen")
plot(data, col=clust.kmMqBag_50_3, pch=19)

#### H-W kmeans -- single / bagged / booted ####
clust.kmHwBootSE_50_3 <- bootItToyClusts(data, 50, "kmeans", 3, "Hartigan-Wong", "SE")
plot(data, col=color.kmHwBootSE_50_3, pch=19, main="Booted H-W Kmeans with SE Consensus
     50 replicates, nStart=3")

clust.kmHwBootGV3_50_2 <- bootItToyClusts(data, 50, "kmeans", 2, "Hartigan-Wong", "GV3")
plot(data, col=color.kmHwBootGV3_50_2, pch=19, main="Booted H-W Kmeans with GV3 Consensus
     50 replicates")

clust.kmHwBootSE_200_2 <- bootItToyClusts(data, 200, "kmeans", 2, "Hartigan-Wong", "SE")
plot(data, col=clust.kmHwBootSE_200_2, pch=19, main="Booted H-W Kmeans with SE Consensus
     200 replicates")

######## FINAL FULL CODE TO APPLY TO EACH DATASET (TOY, CHG, NOW) ######## 
#David Liao and Cara Bowen-Golderg

#### CUSTOM FUNCTIONS -- build model, get consensus/ensemble, cluster sizes, weak membs, quality measures ####
#for 3 clusters
bagItToy <- function(data, nRep, algo, nStart, algoMethod, quality_measures){
  theBag <- cl_bag(data, nRep, 3, algo, parameters=c(nstart=nStart, 
                                                     algorithm=algoMethod, 
                                                     iter.max=100))
  theBag.clustSizes <- table(cl_class_ids(theBag))
  theBag.membership <- as.cl_membership(theBag)
  theBag.memberDf <- data.frame(c1prob=theBag.membership[,1], c2prob=theBag.membership[,2],
                                c3prob=theBag.membership[,3])
  theBag.memberDf$isWeak <- apply(theBag.memberDf, 1, function(x) max(x) < .5)
  theBag.memberDf$hardClus <- as.factor(as.cl_hard_partition(theBag)$.Data)
  theBag.weak <- sum(theBag.memberDf$isWeak)
  
  getSizes <- data.frame(t(as.data.frame(theBag.clustSizes)$Freq))
  
  names(getSizes) <- c('clust1', 'clust2', 'clust3')
  
  theBag.qual = intCriteria(as.matrix(data), as.integer(theBag.memberDf$hardClus),
                            quality_measures)
  #add to results df
  results <- data.frame(as.data.frame(theBag.qual), weak_memb = theBag.weak, getSizes, 
                        row.names =  paste("bag", "k3", algo, algoMethod, nRep, nStart, sep="_"))
  
  return(results)
}
bootItToy <- function(data, nRep, algo, nStart, algoMethod, consMethod, quality_measures){
  theBoot <- cl_boot(data, nRep, 3, algo, parameters=c(nstart=nStart, 
                                                       algorithm=algoMethod, 
                                                       iter.max=100))
  
  bootCons <- cl_consensus(theBoot, method = consMethod)
  
  bootCons.clustSizes <- table(cl_class_ids(bootCons))
  bootCons.membership <- as.cl_membership(bootCons)
  bootCons.memberDf <- data.frame(c1prob=bootCons.membership[,1], c2prob=bootCons.membership[,2],
                                  c3prob=bootCons.membership[,3])
  bootCons.memberDf$isWeak <- apply(bootCons.memberDf, 1, function(x) max(x) < .5)
  bootCons.memberDf$hardClus <- as.factor(as.cl_hard_partition(bootCons)$.Data)
  bootCons.weak <- sum(bootCons.memberDf$isWeak)
  
  getSizes <- data.frame(t(as.data.frame(bootCons.clustSizes)$Freq))
  
  names(getSizes) <- c('clust1', 'clust2', 'clust3')
  
  bootCons.qual = intCriteria(as.matrix(data), as.integer(bootCons.memberDf$hardClus),
                              quality_measures)
  #add to results df
  results <- data.frame(as.data.frame(bootCons.qual), weak_memb = bootCons.weak, getSizes, 
                        row.names =  paste("boot", "k3", algo, algoMethod, consMethod, nRep, nStart, sep="_"))
  
  return(results)
}
bagItToyClusts <- function(data, nRep, algo, nStart, algoMethod){
  theBag <- cl_bag(data, nRep, 3, algo, parameters=c(nstart=nStart, 
                                                     algorithm=algoMethod, 
                                                     iter.max=100))
  hardClus <- as.factor(as.cl_hard_partition(theBag)$.Data)
  return(hardClus)
}
bootItToyClusts <- function(data, nRep, algo, nStart, algoMethod, consMethod){
  theBoot <- cl_boot(data, nRep, 3, algo, parameters=c(nstart=nStart, 
                                                       algorithm=algoMethod, 
                                                       iter.max=100))
  bootCons <- cl_consensus(theBoot, method = consMethod)
  hardClus <- as.factor(as.cl_hard_partition(bootCons)$.Data)
  return(hardClus)
}

########## Single Runs / stuff that doesn't use custom fxn ########## 
#### get single-run cluster model for pam ####
pamSingle <- pam(data, nK, metric = "euclidean", keep.diss=TRUE)
#for 3 clusters
getSizes <- t(as.data.frame(as.integer(pamSingle$clusinfo[,1]), row.names = c('clust1', 'clust2', 'clust3')))

#get quality measures
pamSingle.qual = intCriteria(as.matrix(data), pamSingle$clustering, quality_measures)

#add to results df
results <- data.frame(as.data.frame(pamSingle.qual), weak_memb = 0, getSizes, 
                      row.names = 'pamSingle')

#initialize results DF
resultsOut <- results

#### get single-run cluster models for each of 3 kmeans methods ####
#list of names of k-means methods
kmeans_methods <-   c("Hartigan-Wong", "Lloyd", "MacQueen")

#run kmeans for each of the three methods -- CAN VARY nstart
kmeans_results <- lapply(kmeans_methods, function(m) kmeans(data, nK,  nstart = 2,
                                                            algorithm =m, iter.max = 100) )
names(kmeans_results) <- kmeans_methods

#get each separate
kmHwSingle <- kmeans_results$`Hartigan-Wong`
kmMqSingle <- kmeans_results$MacQueen
kmLloydSingle <- kmeans_results$Lloyd
#### results for singles####
##kmHwSingle##
#for 3 clusters
getSizes <- t(as.data.frame(kmHwSingle$size, row.names = c('clust1', 'clust2', 'clust3')))

kmHwSingle.qual = intCriteria(as.matrix(data), kmHwSingle$cluster, quality_measures)
#add to results df
results <- data.frame(as.data.frame(kmHwSingle.qual), weak_memb = 0, getSizes, 
                      row.names = 'kmHwSingle')
resultsOut <- rbind(resultsOut, results)

##kmMqSingle
#for 3 clusters
getSizes <- t(as.data.frame(kmMqSingle$size, row.names = c('clust1', 'clust2', 'clust3')))

kmMqSingle.qual = intCriteria(as.matrix(data), kmMqSingle$cluster, quality_measures)
#add to results df
results <- data.frame(as.data.frame(kmMqSingle.qual), weak_memb = 0, getSizes, 
                      row.names = 'kmMqSingle')
resultsOut <- rbind(resultsOut, results)

##kmLloydSingle
#for 3 clusters
getSizes <- t(as.data.frame(kmLloydSingle$size, row.names = c('clust1', 'clust2', 'clust3')))

kmLloydSingle.qual = intCriteria(as.matrix(data), kmLloydSingle$cluster, quality_measures)
#add to results df
results <- data.frame(as.data.frame(kmLloydSingle.qual), weak_memb = 0, getSizes, 
                      row.names = 'kmLloydSingle')
resultsOut <- rbind(resultsOut, results)

######### Ensemble of 3 kmeans methods (no reps) with SE and GV3 ########## 

kmeansEns <- cl_ensemble(list = kmeans_results)#####
#### kmSE ####
kmSE <- cl_consensus(kmeansEns, method = "SE") #with consensus method SE 
kmSE.clustSizes <- table(cl_class_ids(kmSE))
kmSE.membership <- as.cl_membership(kmSE)
#if 3 clusters:
kmSE.memberDf <- data.frame(c1prob=kmSE.membership[,1], c2prob=kmSE.membership[,2], 
                            c3prob=kmSE.membership[,3])
kmSE.memberDf$isWeak <- apply(kmSE.memberDf, 1, function(x) max(x) < .5)
kmSE.memberDf$hardClus <- as.factor(as.cl_hard_partition(kmSE)$.Data)
kmSE.weak <- sum(kmSE.memberDf$isWeak)

kmSE.qual = intCriteria(as.matrix(data), as.integer(kmSE.memberDf$hardClus),
                        quality_measures)

#sizes
getSizes <- data.frame(t(as.data.frame(kmSE.clustSizes)$Freq))

#for 3 clusters
names(getSizes) <- c('clust1', 'clust2', 'clust3')

#add to results df 
results <- data.frame(as.data.frame(kmSE.qual, row.names = 'kmSE'), weak_memb = kmSE.weak,
                      getSizes)
resultsOut <- rbind(resultsOut, results)
#### kmGV3 ####
#with GV3 -- a SUMT algorithm for the 'third model' in Gordon and Vichi (2001) for minimizing L with d being co-membership dissimilarity and p = 2 -- much slower
kmGV3 <- cl_consensus(kmeansEns, method = "GV3")

kmGV3.clustSizes <- table(cl_class_ids(kmGV3))
kmGV3.membership <- as.cl_membership(kmGV3)
#if 3 clusters:
kmGV3.memberDf <- data.frame(c1prob=kmGV3.membership[,1], c2prob=kmGV3.membership[,2], 
                             c3prob=kmGV3.membership[,3])

kmGV3.memberDf$isWeak <- apply(kmGV3.memberDf, 1, function(x) max(x) < .5)
kmGV3.memberDf$hardClus <- as.factor(as.cl_hard_partition(kmGV3)$.Data)
kmGV3.weak <- sum(kmGV3.memberDf$isWeak)

#get sizes
getSizes <- data.frame(t(as.data.frame(kmGV3.clustSizes)$Freq))
#for 3 clusters
names(getSizes) <- c('clust1', 'clust2', 'clust3')
kmGV3.qual = intCriteria(as.matrix(data), as.integer(kmGV3.memberDf$hardClus),
                         quality_measures)
#add to results df
results <- data.frame(as.data.frame(kmGV3.qual), weak_memb = kmGV3.weak, getSizes, 
                      row.names = 'kmGV3')

resultsOut <- rbind(resultsOut, results)

####### Pam Bags #######
#### pamBag50 ####
pamBag50 <- cl_bag(data, 50, nK, "pam")

pamBag50.clustSizes <- table(cl_class_ids(pamBag50))
pamBag50.membership <- as.cl_membership(pamBag50)
#if 3 clusters:
pamBag50.memberDf <- data.frame(c1prob=pamBag50.membership[,1], c2prob=pamBag50.membership[,2], 
                                c3prob=pamBag50.membership[,3])

pamBag50.memberDf$isWeak <- apply(pamBag50.memberDf, 1, function(x) max(x) < .5)
pamBag50.memberDf$hardClus <- as.factor(as.cl_hard_partition(pamBag50)$.Data)
pamBag50.weak <- sum(pamBag50.memberDf$isWeak)

getSizes <- data.frame(t(as.data.frame(pamBag50.clustSizes)$Freq))
#for 3 clusters
names(getSizes) <- c('clust1', 'clust2', 'clust3')
pamBag50.qual = intCriteria(as.matrix(data), as.integer(pamBag50.memberDf$hardClus),
                            quality_measures)
#add to results df
results <- data.frame(as.data.frame(pamBag50.qual), weak_memb = pamBag50.weak, getSizes, 
                      row.names = 'pamBag50')

resultsOut <- rbind(resultsOut, results)
#### pamBag100 ####
pamBag100 <- cl_bag(data, 100, nK, "pam")
pamBag100.clustSizes <- table(cl_class_ids(pamBag100))
pamBag100.membership <- as.cl_membership(pamBag100)
#if 3 clusters:
pamBag100.memberDf <- data.frame(c1prob=pamBag100.membership[,1], c2prob=pamBag100.membership[,2], 
                                 c3prob=pamBag100.membership[,3])
pamBag100.memberDf$isWeak <- apply(pamBag100.memberDf, 1, function(x) max(x) < .5)
pamBag100.memberDf$hardClus <- as.factor(as.cl_hard_partition(pamBag100)$.Data)
pamBag100.weak <- sum(pamBag100.memberDf$isWeak)

####PAM BAG 200####
pamBag200 <- cl_bag(data, 200, 3, "pam")

pamBag200.membership <- as.cl_membership(pamBag200)
#if 3 clusters:
pamBag200.memberDf <- data.frame(c1prob=pamBag200.membership[,1], c2prob=pamBag200.membership[,2], 
                                 c3prob=pamBag200.membership[,3])
pamBag200.memberDf$hardClus <- as.factor(as.cl_hard_partition(pamBag200)$.Data)


getSizes <- data.frame(t(as.data.frame(pamBag100.clustSizes)$Freq))
#for 3 clusters
names(getSizes) <- c('clust1', 'clust2', 'clust3')
pamBag100.qual = intCriteria(as.matrix(data), as.integer(pamBag100.memberDf$hardClus),
                             quality_measures)
#add to results df
results <- data.frame(as.data.frame(pamBag100.qual), weak_memb = pamBag100.weak, getSizes, 
                      row.names = 'pamBag100')

resultsOut <- rbind(resultsOut, results)


########## Kmeans Bags (with custom fxn) ########## 
#### MAIN ONES ####
results <- bagItToy(data, 50, "kmeans", 2, "Hartigan-Wong", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagItToy(data, 50, "kmeans", 2, "Lloyd", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagItToy(data, 50, "kmeans", 2, "MacQueen", quality_measures)
resultsOut <- rbind(resultsOut, results)
#### HW BAG VARIATIONS ####
results <- bagItToy(data, 50, "kmeans", 1, "Hartigan-Wong", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagItToy(data, 100, "kmeans", 1, "Hartigan-Wong", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagItToy(data, 100, "kmeans", 2, "Hartigan-Wong", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagItToy(data, 50, "kmeans", 3, "Hartigan-Wong", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagItToy(data, 100, "kmeans", 3, "Hartigan-Wong", quality_measures)
resultsOut <- rbind(resultsOut, results)
#### LLOYD BAG VARIATIONS ####

results <- bagItToy(data, 50, "kmeans", 1, "Lloyd", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagItToy(data, 100, "kmeans", 1, "Lloyd", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagItToy(data, 100, "kmeans", 2, "Lloyd", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagItToy(data, 50, "kmeans", 3, "Lloyd", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagItToy(data, 100, "kmeans", 3, "Lloyd", quality_measures)
resultsOut <- rbind(resultsOut, results)
#### MQ BAG VARIATIONS #####
results <- bagItToy(data, 50, "kmeans", 1, "MacQueen", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagItToy(data, 100, "kmeans", 1, "MacQueen", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagItToy(data, 100, "kmeans", 2, "MacQueen", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagItToy(data, 50, "kmeans", 3, "MacQueen", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagItToy(data, 100, "kmeans", 3, "MacQueen", quality_measures)
resultsOut <- rbind(resultsOut, results)


########## Kmeans Boots (with custom fxn)  ########## 
#### MAIN ONES ####
results <- bootItToy(data, 50, "kmeans", 2, "Hartigan-Wong", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 50, "kmeans", 2, "Hartigan-Wong", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 50, "kmeans", 2, "Lloyd", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 50, "kmeans", 2, "Lloyd", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 50, "kmeans", 2, "MacQueen", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 50, "kmeans", 2, "MacQueen", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

#### HW BOOT VARIATIONS ####
results <- bootItToy(data, 50, "kmeans", 1, "Hartigan-Wong", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 50, "kmeans", 1, "Hartigan-Wong", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 50, "kmeans", 3, "Hartigan-Wong", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 50, "kmeans", 3, "Hartigan-Wong", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 1, "Hartigan-Wong", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 1, "Hartigan-Wong", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 2, "Hartigan-Wong", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 2, "Hartigan-Wong", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 3, "Hartigan-Wong", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 3, "Hartigan-Wong", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)


#### LLOYD BOOT VARIATIONS ####
results <- bootItToy(data, 50, "kmeans", 1, "Lloyd", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 50, "kmeans", 1, "Lloyd", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 50, "kmeans", 3, "Lloyd", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 50, "kmeans", 3, "Lloyd", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 1, "Lloyd", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 1, "Lloyd", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 2, "Lloyd", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 2, "Lloyd", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 3, "Lloyd", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 3, "Lloyd", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)


#### MQ BOOT VARIATIONS ####
results <- bootItToy(data, 50, "kmeans", 1, "MacQueen", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 50, "kmeans", 1, "MacQueen", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 50, "kmeans", 3, "MacQueen", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 50, "kmeans", 3, "MacQueen", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 1, "MacQueen", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 1, "MacQueen", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 2, "MacQueen", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 2, "MacQueen", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 3, "MacQueen", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootItToy(data, 100, "kmeans", 3, "MacQueen", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)


#### FINAL DF OUT -- WRITE TO CSV ####
write.csv(resultsOut, "toyDataResults2.csv")  



intCriteria(as.matrix(toyData$x), as.integer(dbdb$cluster), "S_Dbw")