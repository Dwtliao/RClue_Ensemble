#### CUSTOM FUNCTIONS  -- FOR 8 CLUSTERS####
quality_measures <- c("Dunn", "Calinski_Harabasz", "Silhouette", "Davies_Bouldin",
                      "Xie_Beni", "SD_Dis")


###FOR DATAFRAMES ONLY: includes hard cluster, t/f if weak member, and tract
bagItDf <- function(data, nRep, algo, nStart, algoMethod, tract){
  theBag <- cl_bag(data, nRep, 8, algo, parameters=c(nstart=nStart, 
                                                     algorithm=algoMethod, 
                                                     iter.max=100))
  theBag.membership <- as.cl_membership(theBag)
  theBag.memberDf <- data.frame(c1prob=theBag.membership[,1], c2prob=theBag.membership[,2],
                                c3prob=theBag.membership[,3], c4prob=theBag.membership[,4],
                                c5prob=theBag.membership[,5], c6prob=theBag.membership[,6],
                                c7prob=theBag.membership[,7], c8prob=theBag.membership[,8])
  theBag.memberDf$isWeak <- apply(theBag.memberDf, 1, function(x) max(x) < .5)
  theBag.memberDf$hardClus <- as.factor(as.cl_hard_partition(theBag)$.Data)
  
  theBag.memberDf$tract <- tract
  
  return(theBag.memberDf)
}
bootItDf <- function(data, nRep, algo, nStart, algoMethod, consMethod, tract){
  theBoot <- cl_boot(data, nRep, 8, algo, parameters=c(nstart=nStart, 
                                                       algorithm=algoMethod, 
                                                       iter.max=100))
  
  bootCons <- cl_consensus(theBoot, method = consMethod)
  bootCons.membership <- as.cl_membership(bootCons)
  bootCons.memberDf <- data.frame(c1prob=bootCons.membership[,1], 
                                  c2prob=bootCons.membership[,2],
                                  c3prob=bootCons.membership[,3], 
                                  c4prob=bootCons.membership[,4],
                                  c5prob=bootCons.membership[,5], 
                                  c6prob=bootCons.membership[,6],
                                  c7prob=bootCons.membership[,7], 
                                  c8prob=bootCons.membership[,8])
  bootCons.memberDf$isWeak <- apply(bootCons.memberDf, 1, function(x) max(x) < .5)
  bootCons.memberDf$hardClus <- as.factor(as.cl_hard_partition(bootCons)$.Data)
  
  bootCons.memberDf$tract <- tract
  
  return(bootCons.memberDf)
}

# #example -- bagging with kmeans, hartigan wong, 50 replicates, nstart = 3
# kmHwBag50_3 <- bagItDf(data, 50, "kmeans", 3, "Hartigan-Wong", kmchg.bkp$CensusTract)
# head(kmHwBag50_3)
# 
# #example -- booting with kmeans, hartigan wong, 50 replicates, nstart = 3, consensus = SE
# kmHwBoot50_3 <- bootItDf(data, 50, "kmeans", 3, "Hartigan-Wong", "SE", 
#                          kmchg.bkp$CensusTract)
# head(kmHwBoot50_3)


###FOR MODELS ONLY: to return models only (NOT consensuses) which can be fed to cl_ensemble
bootItModel <- function(data, nRep, algo, nStart, algoMethod){
  theBoot <- cl_boot(data, nRep, 8, algo, parameters=c(nstart=nStart, 
                                                       algorithm=algoMethod, 
                                                       iter.max=100))
  
  return(theBoot)
}

###FOR RESULTS ONLY: cluster sizs, weak members, and quality measures
bagIt <- function(data, nRep, algo, nStart, algoMethod, quality_measures){
  theBag <- cl_bag(data, nRep, 8, algo, parameters=c(nstart=nStart, 
                                                     algorithm=algoMethod, 
                                                     iter.max=100))
  theBag.clustSizes <- table(cl_class_ids(theBag))
  theBag.membership <- as.cl_membership(theBag)
  theBag.memberDf <- data.frame(c1prob=theBag.membership[,1],
                                c2prob=theBag.membership[,2],
                                c3prob=theBag.membership[,3], 
                                c4prob=theBag.membership[,4],
                                c5prob=theBag.membership[,5], 
                                c6prob=theBag.membership[,6],
                                c7prob=theBag.membership[,7], 
                                c8prob=theBag.membership[,8])
  theBag.memberDf$isWeak <- apply(theBag.memberDf, 1, function(x) max(x) < .5)
  theBag.memberDf$hardClus <- as.factor(as.cl_hard_partition(theBag)$.Data)
  theBag.weak <- sum(theBag.memberDf$isWeak)
  
  getSizes <- data.frame(t(as.data.frame(theBag.clustSizes)$Freq))
  
  names(getSizes) <- c('clust1', 'clust2', 'clust3', 'clust4', 'clust5', 'clust6', 'clust7', 'clust8')
  
  theBag.qual = intCriteria(as.matrix(data), as.integer(theBag.memberDf$hardClus),
                            quality_measures)
  #add to results df
  results <- data.frame(as.data.frame(theBag.qual), weak_memb = theBag.weak, getSizes, 
                        row.names =  paste("bag", "k8", algo, algoMethod, nRep, nStart, sep="_"))
  
  return(results)
}
bootIt <- function(data, nRep, algo, nStart, algoMethod, consMethod, quality_measures){
  theBoot <- cl_boot(data, nRep, 8, algo, parameters=c(nstart=nStart, 
                                                       algorithm=algoMethod, 
                                                       iter.max=100))
  
  bootCons <- cl_consensus(theBoot, method = consMethod)
  
  bootCons.clustSizes <- table(cl_class_ids(bootCons))
  bootCons.membership <- as.cl_membership(bootCons)
  bootCons.memberDf <- data.frame(c1prob=bootCons.membership[,1], 
                                  c2prob=bootCons.membership[,2],
                                  c3prob=bootCons.membership[,3], 
                                  c4prob=bootCons.membership[,4],
                                  c5prob=bootCons.membership[,5], 
                                  c6prob=bootCons.membership[,6],
                                  c7prob=bootCons.membership[,7], 
                                  c8prob=bootCons.membership[,8])
  bootCons.memberDf$isWeak <- apply(bootCons.memberDf, 1, function(x) max(x) < .5)
  bootCons.memberDf$hardClus <- as.factor(as.cl_hard_partition(bootCons)$.Data)
  bootCons.weak <- sum(bootCons.memberDf$isWeak)
  
  getSizes <- data.frame(t(as.data.frame(bootCons.clustSizes)$Freq))
  
  names(getSizes) <- c('clust1', 'clust2', 'clust3', 'clust4', 'clust5', 'clust6', 'clust7', 'clust8')
  
  bootCons.qual = intCriteria(as.matrix(data), as.integer(bootCons.memberDf$hardClus),
                              quality_measures)
  #add to results df
  results <- data.frame(as.data.frame(bootCons.qual), weak_memb = bootCons.weak, getSizes, 
                        row.names =  paste("boot", "k8", algo, algoMethod, consMethod, nRep, nStart, sep="_"))
  
  return(results)
}

# #examples
# results <- bagIt(data, 50, "kmeans", 1, "Hartigan-Wong", quality_measures)
# results <- bootIt(data, 50, "kmeans", 2, "Hartigan-Wong", "SE", quality_measures)


#### CUSTOM FUNCTIONS -- FOR 3 CLUSTERS ####
### FOR RESULTS ONLY
bagItToy <- function(data, nRep, algo, nStart, algoMethod, quality_measures){
  theBag <- cl_bag(data, nRep, 3, algo, parameters=c(nstart=nStart, 
                                                     algorithm=algoMethod, 
                                                     iter.max=100))
  theBag.clustSizes <- table(cl_class_ids(theBag))
  theBag.membership <- as.cl_membership(theBag)
  theBag.memberDf <- data.frame(c1prob=theBag.membership[,1], c2prob=theBag.membership[,2],
                                c3prob=theBag.membership[,3])
  theBag.memberDf$isWeak <- apply(theBag.memberDf, 1, function(x) max(x) < .5)
  theBag.memberDf$hardClus <- as.factor(as.cl_hard_partition(theBag)$.Data)
  theBag.weak <- sum(theBag.memberDf$isWeak)
  
  getSizes <- data.frame(t(as.data.frame(theBag.clustSizes)$Freq))
  
  names(getSizes) <- c('clust1', 'clust2', 'clust3')
  
  theBag.qual = intCriteria(as.matrix(data), as.integer(theBag.memberDf$hardClus),
                            quality_measures)
  #add to results df
  results <- data.frame(as.data.frame(theBag.qual), weak_memb = theBag.weak, getSizes, 
                        row.names =  paste("bag", "k3", algo, algoMethod, nRep, nStart, sep="_"))
  
  return(results)
}
bootItToy <- function(data, nRep, algo, nStart, algoMethod, consMethod, 
                      quality_measures){
  theBoot <- cl_boot(data, nRep, 3, algo, parameters=c(nstart=nStart, 
                                                       algorithm=algoMethod, 
                                                       iter.max=100))
  
  bootCons <- cl_consensus(theBoot, method = consMethod)
  
  bootCons.clustSizes <- table(cl_class_ids(bootCons))
  bootCons.membership <- as.cl_membership(bootCons)
  bootCons.memberDf <- data.frame(c1prob=bootCons.membership[,1], c2prob=bootCons.membership[,2],
                                  c3prob=bootCons.membership[,3])
  bootCons.memberDf$isWeak <- apply(bootCons.memberDf, 1, function(x) max(x) < .5)
  bootCons.memberDf$hardClus <- as.factor(as.cl_hard_partition(bootCons)$.Data)
  bootCons.weak <- sum(bootCons.memberDf$isWeak)
  
  getSizes <- data.frame(t(as.data.frame(bootCons.clustSizes)$Freq))
  
  names(getSizes) <- c('clust1', 'clust2', 'clust3')
  
  bootCons.qual = intCriteria(as.matrix(data), as.integer(bootCons.memberDf$hardClus),
                              quality_measures)
  #add to results df
  results <- data.frame(as.data.frame(bootCons.qual), weak_memb = bootCons.weak, getSizes, 
                        row.names =  paste("boot", "k3", algo, algoMethod, consMethod, nRep, nStart, sep="_"))
  
  return(results)
}

### FOR CLUSTER NUMBERS ONLY (TO COLOR MAPS)
bagItToyClusts <- function(data, nRep, algo, nStart, algoMethod){
  theBag <- cl_bag(data, nRep, 3, algo, parameters=c(nstart=nStart, 
                                                     algorithm=algoMethod, 
                                                     iter.max=100))
  hardClus <- as.factor(as.cl_hard_partition(theBag)$.Data)
  return(hardClus)
}
bootItToyClusts <- function(data, nRep, algo, nStart, algoMethod, consMethod){
  theBoot <- cl_boot(data, nRep, 3, algo, parameters=c(nstart=nStart, 
                                                       algorithm=algoMethod, 
                                                       iter.max=100))
  bootCons <- cl_consensus(theBoot, method = consMethod)
  hardClus <- as.factor(as.cl_hard_partition(bootCons)$.Data)
  return(hardClus)
}