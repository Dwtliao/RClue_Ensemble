#---
#  title: "Pam K Medoids 8 Clusters Verification with Clue Ensemble"
#author: "David Liao"
#date: "Feb 8, 2016"
#output: html_document
#---

library(psych)
library(stats)
library(plyr)
library(MASS)
library(leaps)
library(car)
library(corrplot)
library(ggplot2)
library(cluster)   #for clusplot
library(data.table)
library(knitr)
library(dplyr)
library(clusterCrit)  #Compute Internal Validation Indexes of Clusters


##->  REading data and prepare 2 dataframes - 2013 vs Chg data -----------
setwd("C:/Users/David/Google Drive/IHS_CMAP/MasterFiles/Feb5/") 
filePath <- "MasterFile_1980.csv"    #1980 tract rows
CSV_file <- read.csv(filePath1, head=TRUE, sep=",", stringsAsFactors = F) 

cmap2013.df = CSV_file[, c(1, 6, 8, 10, 12:22, 24, 26, 28, 30:32, 34, 36, 38, 40,
                           42, 44, 46:47, 53:57, 59, 61, 63:64, 67, 69, 71, 73:76,84, 86)]  

chg00_13.df = CSV_file[, c(1, 3, 5, 7, 9, 11, 23, 25, 27, 29, 30:31, 33, 35, 37, 39,
                           41, 43, 45, 48:52, 58, 60, 62, 65:66, 68, 70, 72, 77:83, 85, 87:90, 99)]    

#remove desire variables from  datasets 
cmap2013.df$Y13_MedGrRent_Scaled <- NULL
cmap2013.df$Y13_PCT_HUnits_CostBurden_LT30 <- NULL
cmap2013.df$Y14PCT_Renter_Moved1980to1999 <- NULL
cmap2013.df$Y14_PCT_OtherRace_Alone <- NULL
cmap2013.df$Y14_PCT_Not_Hispanic_or_Latino_Total <- NULL
cmap2013.df$Y14_PCT_Two_or_More_Races <- NULL
cmap2013.df$Y13_PCT_OwnerCount <- NULL
cmap2013.df$Y13_MedGrRent_Scaled <- NULL
cmap2013.df$Scaled_PopDensity2013 <- NULL
cmap2013.df$Y13_PCT_HUnits_CostBurden_LT30 <- NULL
cmap2013.df$Y14PCT_Renter_Moved2000to2010_orLater  <- NULL

chg00_13.df$Chg_PCT_MedGrossRent <- NULL
chg00_13.df$OwnerChange <- NULL
chg00_13.df$Change_CostBurden_LTE30 <- NULL
chg00_13.df$Chg_Scaled_PopDensity <- NULL
chg00_13.df$HUD_Housing_Pct_of_HHIncome_hh_h <- NULL
chg00_13.df$HUD_Transportation_Pct_of_HHIncome_hh_t <- NULL
chg00_13.df$Chg_PCT_Not_Hispanic_or_Latino  <- NULL
chg00_13.df$Chg_PCT_OtherRace_Alone   <- NULL
chg00_13.df$Chg_PCT_Two_or_More_Races  <- NULL
chg00_13.df$Scaled_HUDensity2000  <- NULL
#chg00_13.df$Chg_HUDensity  <- NULL

##-- Create separate dataframe for 2013 vs Chg -------
km13.data = data.table(cmap2013.df)
kmchg.data = data.table(chg00_13.df)

#set all NA values to 0 or -1
#km13.data[is.na(km13.data)] = -1
#ignore tracts with missing values
km13.data = na.omit(km13.data)
km13.bkp = km13.data
km13.data$CensusTract <- NULL

##--- omitting NA rows excludes tracts for analysis 
#kmchg.data[is.na(kmchg.data)] = -1

kmgchg.nasbset = na.omit(kmchg.data, invert=TRUE)
kmchg.data = na.omit(kmchg.data)
kmchg.bkp = kmchg.data
kmchg.data$CensusTract <- NULL

##-- Prepare PAM cluster objs for Chg data & 2013 data
set.seed(1234)

#-- Choose CHG DATA 
fitpam8 <- pam(kmchg.data, 8, metric = "euclidean", keep.diss=TRUE)
#-- OR Choose 2013 data
fitpam8 <- pam(km13.data, 8, metric = "euclidean", keep.diss=TRUE)
fitpam8$clusinfo

fitpam8.silhou = as.data.frame(fitpam8$silinfo$widths)
fitpam8$silinfo$clus.avg.widths
fitpam8$silinfo$avg.width
head(fitpam8$diss)

#--- CHG PAM Clusters Output ----------
pam.clusters = as.data.frame(fitpam8$clustering)
pam.clusters$CensusTract =  kmchg.bkp$CensusTract     #tract
pam.data = as.data.frame(kmchg.data)
pam.data$CensusTract =  kmchg.bkp$CensusTract              #tract
pam.clusters <- merge(pam.clusters, pam.data, by="CensusTract")
names(pam.clusters)[2] <- "ClusterNum"    #chg name of Cluster Column 

#--- 2013 PAM Clusters Output ----------
pam.clusters = as.data.frame(fitpam8$clustering)
pam.clusters$CensusTract =  km13.bkp$CensusTract     #tract
pam.data = as.data.frame(km13.data)
pam.data$CensusTract =  km13.bkp$CensusTract              #tract
pam.clusters <- merge(pam.clusters, pam.data, by="CensusTract")
names(pam.clusters)[2] <- "ClusterNum"    #chg name of Cluster Column 

# export a file
newfilename = 'Pam K 8 Clusters Chg Vars RESULTS-Feb 5.csv'
write.csv(pam.clusters, file = newfilename, row.names = FALSE)


fitpam7 <- pam(kmchg.data, 7, metric = "euclidean", keep.diss=TRUE)
fitpam7 <- pam(km13.data, 7, metric = "euclidean", keep.diss=TRUE)
fitpam7$clusinfo
fitpam7.silhou = as.data.frame(fitpam7$silinfo$widths)
fitpam7$silinfo$clus.avg.widths
fitpam7$silinfo$avg.width


fitpam9 <- pam(kmchg.data, 9, metric = "euclidean", keep.diss=TRUE)
fitpam9 <- pam(km13.data, 9, metric = "euclidean", keep.diss=TRUE)
fitpam9$clusinfo
fitpam9.silhou = as.data.frame(fitpam9$silinfo$widths)
fitpam9$silinfo$clus.avg.widths
fitpam9$silinfo$avg.width

##- Plot Silhouette Widths for each cluster ----
plot(fitpam7.silhou$sil_width, fitpam7.silhou$cluster, 
     xlab = "Silhouette Widths" ,
     #ylab = 'Clusters Chg Over Time' ,
     ylab = 'Clusters 2013' ,
     #main = 'Silhouette Widths Chg Over Time 7 Clusters')
     main = 'Silhouette Widths 2013- 7 Clusters')

plot(fitpam8.silhou$sil_width, fitpam8.silhou$cluster, 
     xlab = "Silhouette Widths" ,
     ylab = 'Clusters Chg Over Time' ,
     #ylab = 'Clusters 2013' ,
     main = 'Silhouette Widths Chg Over Time 8 Clusters')
     #main = 'Silhouette Widths 2013- 8 Clusters')

plot(fitpam9.silhou$sil_width, fitpam9.silhou$cluster, 
     xlab = "Silhouette Widths" ,
     #ylab = 'Clusters Chg Over Time' ,
     ylab = 'Clusters 2013' ,
     #main = 'Silhouette Widths Chg Over Time 9 Clusters')
     main = 'Silhouette Widths 2013- 9 Clusters')

setwd("C:/Users/David/Google Drive/CSC529Proj/bagm1_memberships/") 
newfilename = 'Pam 2013 K 7 Clusters Silhouett Widths.csv'
write.csv(fitpam7.silhou, file = newfilename, row.names = FALSE)
newfilename = 'Pam 2013 K 8 Clusters Silhouett Widths.csv'
write.csv(fitpam8.silhou, file = newfilename, row.names = FALSE)
newfilename = 'Pam 2013 K 9 Clusters Silhouett Widths.csv'
write.csv(fitpam9.silhou, file = newfilename, row.names = FALSE)

##-- Calc Internal Validation INdexes on Single Pam K runs---------
pam.clusters = as.data.frame(fitpam8$clustering)
names(pam.clusters)[1] <- "ClusterNum"    #chg name of Cluster Column 

pamclus.IntIDX= intCriteria(as.matrix(kmchg.data), pam.clusters$ClusterNum,c("Dunn", "Calinski_Harabasz",
                            "Silhouette", "Davies_Bouldin","Xie_Beni", "SD_Dis"))
pamclus.IntIDX
pam13clus.IntIDX= intCriteria(as.matrix(km13.data), pam.clusters$ClusterNum, c("Dunn", "Calinski_Harabasz",
                          "Silhouette", "Davies_Bouldin","Xie_Beni", "SD_Dis"))

pam13clus.IntIDX

##---Install CLUE for Ensemble Clustering ------------
library(clue)
library(pryr)  #-- check out oo obj classes

set.seed(1234)

bagm8Chg_100=cl_bag(kmchg.data, 100, 8, "pam")
bagm8Chg_50 =cl_bag(kmchg.data,  50, 8, "pam")

bagm8_50=cl_bag(km13.data, 50, 8, "pam")
bagm8_100=cl_bag(km13.data, 100, 8, "pam")
summary(bagm8)

bagm7=cl_bag(kmchg.data, 100, 7, "pam")  #try k=7 clusters
bagm9=cl_bag(kmchg.data, 100, 9, "pam")  #try k=9 clusters
#bagm7=cl_bag(km13.data, 100, 7, "pam")
#bagm9=cl_bag(km13.data, 100, 9, "pam")

##-- swap out which bagging run to find weak members and Indexes for 
bagm8 = bagm8Chg_100

#extract the rows in each class/cluster
#head(cl_classes(bagm8))
bagm8.clusters = cl_classes(bagm8)
#bagm7.clusters = cl_classes(bagm7)
#bagm9.clusters = cl_classes(bagm9)

##-- compute a few internal indexes 

bagm8HardMembDF = as.cl_hard_partition(bagm8) # convert bagging results into hard mememberships


bagm8.Y13.IntIDX= intCriteria(as.matrix(km13.data), bagm8HardMembDF$.Data, c("Dunn", "Calinski_Harabasz",
                                 "Silhouette", "Davies_Bouldin","Xie_Beni", "SD_Dis"))
bagm8.Y13.IntIDX

bagm8.CHG.IntIDX= intCriteria(as.matrix(kmchg.data), bagm8HardMembDF$.Data,c("Dunn", "Calinski_Harabasz",
                                 "Silhouette", "Davies_Bouldin","Xie_Beni", "SD_Dis"))
bagm8.CHG.IntIDX



###----better way of getting MemberShip data instead of SINK ---------
#bagm1MemberData = as.cl_membership(bagm7)
bagm1MemberData = as.cl_membership(bagm8)
#bagm1MemberData = as.cl_membership(bagm9)

memberDf <- as.data.frame(bagm1MemberData[,1])
names(memberDf) <- "clust1"
memberDf$clust2 <- bagm1MemberData[,2]
memberDf$clust3 <- bagm1MemberData[,3]
memberDf$clust4 <- bagm1MemberData[,4]
memberDf$clust5 <- bagm1MemberData[,5]
memberDf$clust6 <- bagm1MemberData[,6]
memberDf$clust7 <- bagm1MemberData[,7]
memberDf$clust8 <- bagm1MemberData[,8]
#memberDf$clust9 <- bagm1MemberData[,9]

##--> Add census tract back into Data Frame Chg or 2013
memberDf$tract <-  kmchg.bkp$CensusTract
memberDf$tract <-  km13.bkp$CensusTract

head(memberDf)
#bagm7.memb = memberDf
bagm8.memb = memberDf
#bagm9.memb = memberDf

###----Find Weak Members by looking for Prob <= 0.5 ---------

bagm7.memb$weakmemb = 0

for(i in (1:nrow(bagm7.memb))) {
  if(bagm7.memb$clust1[i] > 0.5) {
    bagm7.memb$weakmemb[i] = 0
  } else if (bagm7.memb$clust2[i] > 0.5) {
    bagm7.memb$weakmemb[i] = 0
  } else if (bagm7.memb$clust3[i] > 0.5) {
    bagm7.memb$weakmemb[i] = 0
  } else if (bagm7.memb$clust4[i] > 0.5) {
    bagm7.memb$weakmemb[i] = 0
  } else if (bagm7.memb$clust5[i] > 0.5) {
    bagm7.memb$weakmemb[i] = 0
  } else if (bagm7.memb$clust6[i] > 0.5) {
    bagm7.memb$weakmemb[i] = 0
  } else if (bagm7.memb$clust7[i] > 0.5) {
    bagm7.memb$weakmemb[i] = 0
  } else (bagm7.memb$weakmemb[i] = 1)   #no cluster has probability > 0.5
}

bagm7.weak = data.table(bagm7.memb)
bagm7.weak = as.data.frame( bagm7.weak[weakmemb == 1, ] )

bagm8.memb$weakmemb = 0

for(i in (1:nrow(bagm8.memb))) {
  if(bagm8.memb$clust1[i] > 0.5) {
    bagm8.memb$weakmemb[i] = 0
  } else if (bagm8.memb$clust2[i] > 0.5) {
    bagm8.memb$weakmemb[i] = 0
  } else if (bagm8.memb$clust3[i] > 0.5) {
    bagm8.memb$weakmemb[i] = 0
  } else if (bagm8.memb$clust4[i] > 0.5) {
    bagm8.memb$weakmemb[i] = 0
  } else if (bagm8.memb$clust5[i] > 0.5) {
    bagm8.memb$weakmemb[i] = 0
  } else if (bagm8.memb$clust6[i] > 0.5) {
    bagm8.memb$weakmemb[i] = 0
  } else if (bagm8.memb$clust7[i] > 0.5) {
    bagm8.memb$weakmemb[i] = 0
  } else if (bagm8.memb$clust8[i] > 0.5) {
    bagm8.memb$weakmemb[i] = 0
  } else (bagm8.memb$weakmemb[i] = 1)  #no cluster has probability > 0.5
}

bagm8.weak = data.table(bagm8.memb)
bagm8.weak = as.data.frame( bagm8.weak[weakmemb == 1, ] )
nrow(bagm8.weak)

bagm9.memb$weakmemb = 0

for(i in (1:nrow(bagm9.memb))) {
  if(bagm9.memb$clust1[i] > 0.5) {
    bagm9.memb$weakmemb[i] = 0
  } else if (bagm9.memb$clust2[i] > 0.5) {
    bagm9.memb$weakmemb[i] = 0
  } else if (bagm9.memb$clust3[i] > 0.5) {
    bagm9.memb$weakmemb[i] = 0
  } else if (bagm9.memb$clust4[i] > 0.5) {
    bagm9.memb$weakmemb[i] = 0
  } else if (bagm9.memb$clust5[i] > 0.5) {
    bagm9.memb$weakmemb[i] = 0
  } else if (bagm9.memb$clust6[i] > 0.5) {
    bagm9.memb$weakmemb[i] = 0
  } else if (bagm9.memb$clust7[i] > 0.5) {
    bagm9.memb$weakmemb[i] = 0
  } else if (bagm9.memb$clust8[i] > 0.5) {
    bagm9.memb$weakmemb[i] = 0
  } else if (bagm9.memb$clust9[i] > 0.5) {
    bagm9.memb$weakmemb[i] = 0
  } else (bagm9.memb$weakmemb[i] = 1)  #no cluster has probability > 0.5
}

bagm9.weak = data.table(bagm9.memb)
bagm9.weak = as.data.frame( bagm9.weak[weakmemb == 1, ] )

##-write out file to save results of Weak Memberships ----------
setwd("C:/Users/David/Google Drive/CSC529Proj/bagm1_memberships/") 
newfilename = 'Pam K 7 2013 Clusters Bagging Weak Memberships.csv'
write.csv(bagm7.memb, file = newfilename, row.names = FALSE)
newfilename = 'Pam K 7 2013 Clusters Bagging Weak Members ONLY.csv'
write.csv(bagm7.weak, file = newfilename, row.names = FALSE)

newfilename = 'Pam K 8 2013 Clusters Bagging Weak Memberships.csv'
write.csv(bagm8.memb, file = newfilename, row.names = FALSE)
newfilename = 'Pam K 8 2013 Clusters Bagging Weak Members ONLY.csv'
write.csv(bagm8.weak, file = newfilename, row.names = FALSE)

newfilename = 'Pam K 9 2013 Clusters Bagging Weak Memberships.csv'
write.csv(bagm9.memb, file = newfilename, row.names = FALSE)
newfilename = 'Pam K 9 2013 Clusters Bagging Weak Members ONLY.csv'
write.csv(bagm9.weak, file = newfilename, row.names = FALSE)
