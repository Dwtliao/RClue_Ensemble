##- CSC-529 Plot of Pam K8 census tract vs results of ENsemble Clustering --------

##--- Libraries required for Geo Map Tracts plot-----------
library(dplyr)
library(rgdal)
library(scales)
library(ggmap)
library(Cairo)
library(ggplot2)
# install.packages("gpclib", type="source") # RUN THIS IF YOU GET AN ERROR ON 'fortify' BELOW
library(rgeos)
library(maptools)
library(data.table)
library(RColorBrewer)


##-- Setup directories for GEO PLOT ShapeFiles ---------
setwd("C:/Users/David/Google Drive/CSC529Proj/geoplots")

#*- NEW tract shapefiles for all of ILLINOIS !----
tract.shapefile <- read.csv("tract_shapefile_2010.csv", head=TRUE, sep=",", stringsAsFactors = F)

filePath2 <- "CensusTract2013_to_CountyIDs_forShapeFiles.csv"   #Tract to County ID relationships
CSV_file2 <- read.csv(filePath2, head=TRUE, sep=",", stringsAsFactors = F) #CountyIDs

#--cast your CountyID column as.character (in new col) for join to work----
CSV_file2$countyidChar <- as.character(CSV_file2$CountyID)  
CSV_file2$tractidChar <- as.character(CSV_file2$CensusTract2013)
CSV_file2$CensusTract2013 = as.character(CSV_file2$CensusTract2013)
CSV_file2$CensusTract = paste("1400000US", CSV_file2$CensusTract2013, sep = "")


# county shapefile
county.shapefile <- read.csv("county_shapefile_2010.csv", head=TRUE, sep=",", stringsAsFactors = F)


#---read clusters from external file instead ---------
#filePath1 <- "Pam K8 ClusterResults-Mar3.csv"   #Don't USE Mar 3 Pam k8 cluster results
setwd("C:/Users/David/Google Drive/CSC529Proj/geoplots/QryClusterResults")
setwd("C:/Users/dliao/Google Drive/CSC529Proj/geoplots/QryClusterResults")

filePath1 <- "Pam K 8 Clusters Chg Vars RESULTS-Feb 5.csv"    #Need 1906 tracts to match Ensemble
#-- OR -- 2013 results
filePath1 <- "Pam K 8 Clusters 2013 Vars RESULTS-Feb 5.csv"    #Need 1906 tracts to match Ensemble

PamK8_file <- read.csv(filePath1, head=TRUE, sep=",", stringsAsFactors = F) 
PamK8_Clusters = PamK8_file[, c(1:2)]   #Just Tract #s with Cluster Assignments Y13 & CHG
names(PamK8_Clusters)[2] <- "Cluster_CHG"

####- DECIDE WHAT IT IS YOU WANT TO PLOT?? --------------------
##-- only use this line below to print all 8 Clusters on 1 map ---
pamchg.output = as.data.frame(PamK8_Clusters)


##-Add col for color coding instead of Cluster values to color by CHANGE
pamchg.output$Color <- "Z_NoColor"
pamchg.output$Color[pamchg.output$Cluster_CHG == 8] <- c("H_HighGrowth")
pamchg.output$Color[pamchg.output$Cluster_CHG == 7] <- c("G_MedGrowth")
pamchg.output$Color[pamchg.output$Cluster_CHG == 6] <- c("F_MiddleClassBurbs")
pamchg.output$Color[pamchg.output$Cluster_CHG == 5] <- c("E_WealthySuburbs")
pamchg.output$Color[pamchg.output$Cluster_CHG == 4] <- c("D_HardshipOuterCity")
pamchg.output$Color[pamchg.output$Cluster_CHG == 3] <- c("C_YoungGentrified")
pamchg.output$Color[pamchg.output$Cluster_CHG == 2] <- c("B_HardshipInnerCity")
pamchg.output$Color[pamchg.output$Cluster_CHG == 1] <- c("A_NoChgSteady")

##-- And then skip this next section UNLESS you want to print 1 cluster at a time -------------

##------- try to map only 1 cluster at a time ------------
pamchg.bkp = data.table(PamK8_Clusters)

cluster8pam = as.data.frame( pamchg.bkp[Cluster_CHG == 8] )
cluster7pam = as.data.frame( pamchg.bkp[Cluster_CHG == 7] )
cluster6pam = as.data.frame( pamchg.bkp[Cluster_CHG == 6] )
cluster5pam = as.data.frame( pamchg.bkp[Cluster_CHG == 5] )
cluster4pam = as.data.frame( pamchg.bkp[Cluster_CHG == 4] )
cluster3pam = as.data.frame( pamchg.bkp[Cluster_CHG == 3] )
cluster2pam = as.data.frame( pamchg.bkp[Cluster_CHG == 2] )
cluster1pam = as.data.frame( pamchg.bkp[Cluster_CHG == 1] )
cluster45pam = as.data.frame( pamchg.bkp[Cluster_CHG == 5 | Cluster_CHG == 4] )  # OR condition
cluster67pam = as.data.frame( pamchg.bkp[Cluster_CHG == 6 | Cluster_CHG == 7] )  # OR condition
cluster56pam = as.data.frame( pamchg.bkp[Cluster_CHG == 5 | Cluster_CHG == 6] )  # OR condition

pamchg.output = cluster8pam
##-END of skip this next section UNLESS you want to print 1 cluster at a time -------------

names(pamchg.output)[1] <- "tract"    #chg name of Census Tract Column

#-- column of Tract IDs must be of type CHAR for join to work---
pamchg.output$tractChar <- as.character(pamchg.output$tract)  #CAST ur TRACT AS.CHARACTER IN NEW COLUMN

##-- WHicH RESULTS are you plotting??-- swap Cluster Values between Y13 & Chg- ---
#names(pamchg.output)[3] <- "cluster1"    #use CHG CLusters to plot and USE for JOIN below!
 names(pamchg.output)[2] <- "cluster1"  #use CHG CLusters to plot and USE for JOIN below!


##-  Add prefix to Tract Char values--- for County Shape Files
pamchg.output$tractChar = paste("1400000US", pamchg.output$tractChar, sep = "")

#-- set DEFAULT margins for plots
par(mar=c(5, 4, 4, 2))   #default

#--Create Chicago Tract Map PLOTdata from Clustering Results  ------
plotData <- left_join(tract.shapefile, pamchg.output, by = c("id" = "tractChar")) #join data to the map data


clusterdata <- left_join(pamchg.output, CSV_file2, by = c("tractChar" = "CensusTract")) 
county.shapefile$id = as.character(county.shapefile$id)

plotDataCounty <- left_join(county.shapefile, clusterdata, by = c("id" = "countyidChar"))

##- check out some brewer.pal color schemes ---------
###-  http://www.inside-r.org/packages/cran/RColorBrewer/docs/ColorBrewer--------
#display.brewer.pal(8,"Accent")
#mypalette<-brewer.pal(8,"Accent")

#--color your map by your clusters CSV_file$cluster1 WITH COUNTY ID Boundaries shown -----
yourMap <- ggplot(plotData, aes(long, lat, group = group)) +
  geom_polygon(aes(fill = factor(cluster1)), colour = "black", size = 0.2) + 
  geom_polygon(data = plotDataCounty, colour = "white", fill = NA)  +
  scale_fill_brewer(type="qual",palette="Accent") +
  #ggtitle("Pam K8 2013 Housing Segments-Cluster 8 Only")
  #scale_fill_brewer(type="div",palette=5)+
  #scale_fill_brewer(type="qual",palette="Accent", direction = 1)+
  #scale_fill_brewer(type="seq",palette=6)+
  ggtitle("Pam K8 2013 Housing Segments-1906 Tracts")
  

#print(yourMap)
setwd("C:/Users/dliao/Google Drive/CSC529Proj/geoplots/PamK2013Plots2/")
#ggsave(yourMap, file = "Pam K8 2013 Clusters-Cluster 8.png", width = 10, height = 9, type = "cairo-png")

ggsave(yourMap, file = "Pam K8 2013 Clusters-1909Tracts.png", width = 10, height = 9, type = "cairo-png")

#--color your map by Cluster NAMES WITH COUNTY ID Boundaries shown -----
yourMap <- ggplot(plotData, aes(long, lat, group = group)) +
  geom_polygon(aes(fill = factor(Color)), colour = "black", size = 0.2) + 
  geom_polygon(data = plotDataCounty, colour = "white", fill = NA)  +
  
  #scale_fill_brewer(type="div",palette=5)+
  scale_fill_brewer(type="qual",palette="Accent", direction = 1)+   #Chg direction of colors
  #scale_fill_brewer(type="seq",palette=5)+
  ggtitle("Pam K8 CHG Housing Segments-Mar3")

#print(yourMap)

ggsave(yourMap, file = "Pam K8 Clusters-Mar3_ClusNames.png", width = 10, height = 9, type = "cairo-png")
