######## FINAL FULL CODE TO APPLY TO EACH DATASET (TOY, CHG, NOW) ######## 
#David Liao and Cara Bowen-Golderg

####LIBS AND SEED####
library(clue)
# install.packages("clusterCrit")
library(clusterCrit)
library(e1071)
library(cluster)

set.seed(1234)

# memory.limit(size=8000)

#### LOAD DATA AND ASSIGN STUFF ####
###ASSIGN DATA TO THE 'data' OBJECT HERE ###  
data <- kmchg.data
# data <- km13.data
# data <- toyData$x  
  
### ASSIGN NUMBER OF CLUSTERS HERE ###
nK <- 8
# nK <- 3

### ASSIGN N START HERE ###
# nStart <- 1
nStart <- 2
# nStart <- 3  

quality_measures <- c("Dunn", "Calinski_Harabasz", "Silhouette", "Davies_Bouldin",
                      "Xie_Beni", "SD_Dis")

#### CUSTOM FUNCTIONS -- build model, get consensus/ensemble, cluster sizes, weak membs, quality measures ####
#for 8 clusters
bagIt <- function(data, nRep, algo, nStart, algoMethod, quality_measures){
  theBag <- cl_bag(data, nRep, 8, algo, parameters=c(nstart=nStart, 
                                                     algorithm=algoMethod, 
                                                     iter.max=100))
  theBag.clustSizes <- table(cl_class_ids(theBag))
  theBag.membership <- as.cl_membership(theBag)
  theBag.memberDf <- data.frame(c1prob=theBag.membership[,1],
                                c2prob=theBag.membership[,2],
                                c3prob=theBag.membership[,3], 
                                c4prob=theBag.membership[,4],
                                c5prob=theBag.membership[,5], 
                                c6prob=theBag.membership[,6],
                                c7prob=theBag.membership[,7], 
                                c8prob=theBag.membership[,8])
  theBag.memberDf$isWeak <- apply(theBag.memberDf, 1, function(x) max(x) < .5)
  theBag.memberDf$hardClus <- as.factor(as.cl_hard_partition(theBag)$.Data)
  theBag.weak <- sum(theBag.memberDf$isWeak)
  
  getSizes <- data.frame(t(as.data.frame(theBag.clustSizes)$Freq))
  
  names(getSizes) <- c('clust1', 'clust2', 'clust3', 'clust4', 'clust5', 'clust6', 'clust7', 'clust8')
  
  theBag.qual = intCriteria(as.matrix(data), as.integer(theBag.memberDf$hardClus),
                            quality_measures)
  #add to results df
  results <- data.frame(as.data.frame(theBag.qual), weak_memb = theBag.weak, getSizes, 
                        row.names =  paste("bag", "k8", algo, algoMethod, nRep, nStart, sep="_"))
  
  return(results)
}
bootIt <- function(data, nRep, algo, nStart, algoMethod, consMethod, quality_measures){
  theBoot <- cl_boot(data, nRep, 8, algo, parameters=c(nstart=nStart, 
                                                       algorithm=algoMethod, 
                                                       iter.max=100))
  
  bootCons <- cl_consensus(theBoot, method = consMethod)
  
  bootCons.clustSizes <- table(cl_class_ids(bootCons))
  bootCons.membership <- as.cl_membership(bootCons)
  bootCons.memberDf <- data.frame(c1prob=bootCons.membership[,1], 
                                  c2prob=bootCons.membership[,2],
                                  c3prob=bootCons.membership[,3], 
                                  c4prob=bootCons.membership[,4],
                                  c5prob=bootCons.membership[,5], 
                                  c6prob=bootCons.membership[,6],
                                  c7prob=bootCons.membership[,7], 
                                  c8prob=bootCons.membership[,8])
  bootCons.memberDf$isWeak <- apply(bootCons.memberDf, 1, function(x) max(x) < .5)
  bootCons.memberDf$hardClus <- as.factor(as.cl_hard_partition(bootCons)$.Data)
  bootCons.weak <- sum(bootCons.memberDf$isWeak)
  
  getSizes <- data.frame(t(as.data.frame(bootCons.clustSizes)$Freq))
  
  names(getSizes) <- c('clust1', 'clust2', 'clust3', 'clust4', 'clust5', 'clust6', 'clust7', 'clust8')
  
  bootCons.qual = intCriteria(as.matrix(data), as.integer(bootCons.memberDf$hardClus),
                              quality_measures)
  #add to results df
  results <- data.frame(as.data.frame(bootCons.qual), weak_memb = bootCons.weak, getSizes, 
                        row.names =  paste("boot", "k8", algo, algoMethod, consMethod, nRep, nStart, sep="_"))
  
  return(results)
}

########## Single Runs / stuff that doesn't use custom fxn ########## 
#### get single-run cluster model for pam ####
pamSingle <- pam(data, nK, metric = "euclidean", keep.diss=TRUE)
#for 8 clusters
getSizes <- t(as.data.frame(as.integer(pamSingle$clusinfo[,1]), 
                            row.names = c('clust1', 'clust2', 'clust3', 'clust4', 'clust5',
                                          'clust6', 'clust7', 'clust8')))

#get quality measures
pamSingle.qual = intCriteria(as.matrix(data), pamSingle$clustering, quality_measures)

#add to results df
results <- data.frame(as.data.frame(pamSingle.qual), weak_memb = 0, getSizes, 
                      row.names = 'pamSingle')

#initialize results DF
resultsOut <- results
#### get single-run cluster models for each of 3 kmeans methods ####
#list of names of k-means methods
kmeans_methods <-   c("Hartigan-Wong", "Lloyd", "MacQueen")

#run kmeans for each of the three methods -- CAN VARY nstart
kmeans_results <- lapply(kmeans_methods, function(m) kmeans(data, nK,  nstart = nStart,
                                                            algorithm =m, iter.max = 100) )
names(kmeans_results) <- kmeans_methods

#get each separate
kmHwSingle <- kmeans_results$`Hartigan-Wong`
kmMqSingle <- kmeans_results$MacQueen
kmLloydSingle <- kmeans_results$Lloyd
#### results for singles####
##kmHwSingle##
#for 8 clusters
getSizes <- t(as.data.frame(kmHwSingle$size, row.names = c('clust1', 'clust2', 'clust3',
                                                           'clust4', 'clust5', 'clust6',
                                                           'clust7', 'clust8')))

kmHwSingle.qual = intCriteria(as.matrix(data), kmHwSingle$cluster, quality_measures)
#add to results df
results <- data.frame(as.data.frame(kmHwSingle.qual), weak_memb = 0, getSizes, 
                      row.names = 'kmHwSingle')
resultsOut <- rbind(resultsOut, results)

##kmMqSingle
#for 8 clusters
getSizes <- t(as.data.frame(kmMqSingle$size, row.names = c('clust1', 'clust2', 'clust3',
                                                           'clust4', 'clust5', 'clust6',
                                                           'clust7', 'clust8')))

kmMqSingle.qual = intCriteria(as.matrix(data), kmMqSingle$cluster, quality_measures)
#add to results df
results <- data.frame(as.data.frame(kmMqSingle.qual), weak_memb = 0, getSizes, 
                      row.names = 'kmMqSingle')
resultsOut <- rbind(resultsOut, results)

##kmLloydSingle
#for 8 clusters
getSizes <- t(as.data.frame(kmLloydSingle$size, row.names = c('clust1', 'clust2', 'clust3',
                                                              'clust4', 'clust5', 'clust6',
                                                              'clust7', 'clust8')))

kmLloydSingle.qual = intCriteria(as.matrix(data), kmLloydSingle$cluster, quality_measures)
#add to results df
results <- data.frame(as.data.frame(kmLloydSingle.qual), weak_memb = 0, getSizes, 
                      row.names = 'kmLloydSingle')
resultsOut <- rbind(resultsOut, results)

######### Ensemble of 3 kmeans methods (no reps) with SE and GV3 ########## 
kmeansEns <- cl_ensemble(list = kmeans_results)#####
#### kmSE ####
kmSE <- cl_consensus(kmeansEns, method = "SE") #with consensus method SE 
kmSE.clustSizes <- table(cl_class_ids(kmSE))
kmSE.membership <- as.cl_membership(kmSE)
#if 8 clusters:
kmSE.memberDf <- data.frame(c1prob=kmSE.membership[,1], c2prob=kmSE.membership[,2], 
                            c3prob=kmSE.membership[,3], c4prob=kmSE.membership[,4],
                            c5prob=kmSE.membership[,5], c6prob=kmSE.membership[,6],
                            c7prob=kmSE.membership[,7], c8prob=kmSE.membership[,8])
kmSE.memberDf$isWeak <- apply(kmSE.memberDf, 1, function(x) max(x) < .5)
kmSE.memberDf$hardClus <- as.factor(as.cl_hard_partition(kmSE)$.Data)
kmSE.weak <- sum(kmSE.memberDf$isWeak)

kmSE.qual = intCriteria(as.matrix(data), as.integer(kmSE.memberDf$hardClus),
                        quality_measures)

#sizes
getSizes <- data.frame(t(as.data.frame(kmSE.clustSizes)$Freq))
#for 8 clusters
names(getSizes) <- c('clust1', 'clust2', 'clust3', 'clust4', 'clust5', 'clust6', 'clust7',
                     'clust8')
#add to results df
results <- data.frame(as.data.frame(kmSE.qual, row.names = 'kmSE'), weak_memb = kmSE.weak,
                      getSizes)
resultsOut <- rbind(resultsOut, results)

#### kmGV3 ####
#with GV3 -- a SUMT algorithm for the 'third model' in Gordon and Vichi (2001) for minimizing L with d being co-membership dissimilarity and p = 2 -- much slower
kmGV3 <- cl_consensus(kmeansEns, method = "GV3") 

kmGV3.clustSizes <- table(cl_class_ids(kmGV3))
kmGV3.membership <- as.cl_membership(kmGV3)

#if 8 clusters:
kmGV3.memberDf <- data.frame(c1prob=kmGV3.membership[,1], c2prob=kmGV3.membership[,2], 
                             c3prob=kmGV3.membership[,3], c4prob=kmGV3.membership[,4],
                             c5prob=kmGV3.membership[,5], c6prob=kmGV3.membership[,6],
                             c7prob=kmGV3.membership[,7], c8prob=kmGV3.membership[,8])
kmGV3.memberDf$isWeak <- apply(kmGV3.memberDf, 1, function(x) max(x) < .5)
kmGV3.memberDf$hardClus <- as.factor(as.cl_hard_partition(kmGV3)$.Data)
kmGV3.weak <- sum(kmGV3.memberDf$isWeak)

#get sizes
getSizes <- data.frame(t(as.data.frame(kmGV3.clustSizes)$Freq))
#for 8 clusters
names(getSizes) <- c('clust1', 'clust2', 'clust3', 'clust4', 'clust5', 'clust6', 'clust7',
                     'clust8')


kmGV3.qual = intCriteria(as.matrix(data), as.integer(kmGV3.memberDf$hardClus),
                         quality_measures)
#add to results df
results <- data.frame(as.data.frame(kmGV3.qual), weak_memb = kmGV3.weak, getSizes, 
                      row.names = 'kmGV3')

resultsOut <- rbind(resultsOut, results)

####### Pam Bags #######
#### pamBag50 ####
pamBag50 <- cl_bag(data, 50, nK, "pam")

pamBag50.clustSizes <- table(cl_class_ids(pamBag50))
pamBag50.membership <- as.cl_membership(pamBag50)

#if 8 clusters:
pamBag50.memberDf <- data.frame(c1prob=pamBag50.membership[,1], 
                                c2prob=pamBag50.membership[,2],
                                c3prob=pamBag50.membership[,3], 
                                c4prob=pamBag50.membership[,4],
                                c5prob=pamBag50.membership[,5], 
                                c6prob=pamBag50.membership[,6],
                                c7prob=pamBag50.membership[,7], 
                                c8prob=pamBag50.membership[,8])
pamBag50.memberDf$isWeak <- apply(pamBag50.memberDf, 1, function(x) max(x) < .5)
pamBag50.memberDf$hardClus <- as.factor(as.cl_hard_partition(pamBag50)$.Data)
pamBag50.weak <- sum(pamBag50.memberDf$isWeak)

getSizes <- data.frame(t(as.data.frame(pamBag50.clustSizes)$Freq))
#for 8 clusters
names(getSizes) <- c('clust1', 'clust2', 'clust3', 'clust4', 'clust5', 'clust6', 'clust7',
                     'clust8')

pamBag50.qual = intCriteria(as.matrix(data), as.integer(pamBag50.memberDf$hardClus),
                            quality_measures)
#add to results df
results <- data.frame(as.data.frame(pamBag50.qual), weak_memb = pamBag50.weak, getSizes, 
                      row.names = 'pamBag50')

resultsOut <- rbind(resultsOut, results)

#### pamBag100 ####
pamBag100 <- cl_bag(data, 100, nK, "pam")
pamBag100.clustSizes <- table(cl_class_ids(pamBag100))
pamBag100.membership <- as.cl_membership(pamBag100)
#if 8 clusters:
pamBag100.memberDf <- data.frame(c1prob=pamBag100.membership[,1], 
                                 c2prob=pamBag100.membership[,2],
                                 c3prob=pamBag100.membership[,3], 
                                 c4prob=pamBag100.membership[,4],
                                 c5prob=pamBag100.membership[,5], 
                                 c6prob=pamBag100.membership[,6],
                                 c7prob=pamBag100.membership[,7], 
                                 c8prob=pamBag100.membership[,8])
pamBag100.memberDf$isWeak <- apply(pamBag100.memberDf, 1, function(x) max(x) < .5)
pamBag100.memberDf$hardClus <- as.factor(as.cl_hard_partition(pamBag100)$.Data)
pamBag100.weak <- sum(pamBag100.memberDf$isWeak)

getSizes <- data.frame(t(as.data.frame(pamBag100.clustSizes)$Freq))
#for 8 clusters
names(getSizes) <- c('clust1', 'clust2', 'clust3', 'clust4', 'clust5', 'clust6', 'clust7',
                     'clust8')
pamBag100.qual = intCriteria(as.matrix(data), as.integer(pamBag100.memberDf$hardClus),
                             quality_measures)
#add to results df
results <- data.frame(as.data.frame(pamBag100.qual), weak_memb = pamBag100.weak, getSizes, 
                      row.names = 'pamBag100')

resultsOut <- rbind(resultsOut, results)

########## Kmeans Bags (with custom fxn) ########## 
#### MAIN ONES ####
results <- bagIt(data, 50, "kmeans", 2, "Hartigan-Wong", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagIt(data, 50, "kmeans", 2, "Lloyd", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bagIt(data, 50, "kmeans", 2, "MacQueen", quality_measures)
resultsOut <- rbind(resultsOut, results)
#### HW BAG VARIATIONS ####
# results <- bagIt(data, 50, "kmeans", 1, "Hartigan-Wong", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bagIt(data, 100, "kmeans", 1, "Hartigan-Wong", quality_measures)
# resultsOut <- rbind(resultsOut, results)

# results <- bagIt(data, 100, "kmeans", 2, "Hartigan-Wong", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bagIt(data, 50, "kmeans", 3, "Hartigan-Wong", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bagIt(data, 100, "kmeans", 3, "Hartigan-Wong", quality_measures)
# resultsOut <- rbind(resultsOut, results)
#### LLOYD BAG VARIATIONS ####

# results <- bagIt(data, 50, "kmeans", 1, "Lloyd", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bagIt(data, 100, "kmeans", 1, "Lloyd", quality_measures)
# resultsOut <- rbind(resultsOut, results)

# results <- bagIt(data, 100, "kmeans", 2, "Lloyd", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bagIt(data, 50, "kmeans", 3, "Lloyd", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bagIt(data, 100, "kmeans", 3, "Lloyd", quality_measures)
# resultsOut <- rbind(resultsOut, results)
#### MQ BAG VARIATIONS #####
# results <- bagIt(data, 50, "kmeans", 1, "MacQueen", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bagIt(data, 100, "kmeans", 1, "MacQueen", quality_measures)
# resultsOut <- rbind(resultsOut, results)

# results <- bagIt(data, 100, "kmeans", 2, "MacQueen", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bagIt(data, 50, "kmeans", 3, "MacQueen", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bagIt(data, 100, "kmeans", 3, "MacQueen", quality_measures)
# resultsOut <- rbind(resultsOut, results)


########## Kmeans Boots (with custom fxn)  ########## 
#### MAIN ONES ####
results <- bootIt(data, 50, "kmeans", 2, "Hartigan-Wong", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootIt(data, 50, "kmeans", 2, "Hartigan-Wong", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootIt(data, 50, "kmeans", 2, "Lloyd", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootIt(data, 50, "kmeans", 2, "Lloyd", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootIt(data, 50, "kmeans", 2, "MacQueen", "SE", quality_measures)
resultsOut <- rbind(resultsOut, results)

results <- bootIt(data, 50, "kmeans", 2, "MacQueen", "GV3", quality_measures)
resultsOut <- rbind(resultsOut, results)

#### HW BOOT VARIATIONS ####
# results <- bootIt(data, 50, "kmeans", 1, "Hartigan-Wong", "SE", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 50, "kmeans", 1, "Hartigan-Wong", "GV3", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 50, "kmeans", 3, "Hartigan-Wong", "SE", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 50, "kmeans", 3, "Hartigan-Wong", "GV3", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 1, "Hartigan-Wong", "SE", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 1, "Hartigan-Wong", "GV3", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 2, "Hartigan-Wong", "SE", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 2, "Hartigan-Wong", "GV3", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 3, "Hartigan-Wong", "SE", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 3, "Hartigan-Wong", "GV3", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 

#### LLOYD BOOT VARIATIONS ####
# results <- bootIt(data, 50, "kmeans", 1, "Lloyd", "SE", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 50, "kmeans", 1, "Lloyd", "GV3", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 50, "kmeans", 3, "Lloyd", "SE", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 50, "kmeans", 3, "Lloyd", "GV3", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 1, "Lloyd", "SE", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 1, "Lloyd", "GV3", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 2, "Lloyd", "SE", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 2, "Lloyd", "GV3", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 3, "Lloyd", "SE", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 3, "Lloyd", "GV3", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 

#### MQ BOOT VARIATIONS ####
# results <- bootIt(data, 50, "kmeans", 1, "MacQueen", "SE", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 50, "kmeans", 1, "MacQueen", "GV3", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 50, "kmeans", 3, "MacQueen", "SE", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 50, "kmeans", 3, "MacQueen", "GV3", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 1, "MacQueen", "SE", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 1, "MacQueen", "GV3", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 2, "MacQueen", "SE", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 2, "MacQueen", "GV3", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 3, "MacQueen", "SE", quality_measures)
# resultsOut <- rbind(resultsOut, results)
# 
# results <- bootIt(data, 100, "kmeans", 3, "MacQueen", "GV3", quality_measures)
# resultsOut <- rbind(resultsOut, results)


#### FINAL DF OUT -- WRITE TO CSV ####
#write.csv(resultsOut, "chgDataResults.csv")  
write.csv(resultsOut, "nowDataResults.csv")  
# write.csv(resultsOut, "toyDataResults.csv")  
